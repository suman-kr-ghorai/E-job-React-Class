import './App.css'
import Users from './Users'

function App() {

  return (
    <>
      <Users/>
    </>
  )
}

export default App
